{- |
Module      :  Assignment07
Description :  Assignment 7 submission for CS 4400.
Copyright   :  (c) Kevin Zhang

Maintainer  :  zhang.kevi@northeastern.edu
-}

module Assignment07 where

fact4StepsBefore = 8050
fact4StepsAfter = 4914
